/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Host;

import Common.Database_Properties;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Jonty
 */
public class Change_Fare extends javax.swing.JFrame {

    /**
     * Creates new form Main_Frame
     */
    public Change_Fare() {
        initComponents();
    }
    
    String to_find = "";
  
    private int citytoint(String city) {
        int code = -1;
        String[] cities = new String[22];
        cities[0] = "Amritsar";
        cities[1] = "Barnala";
        cities[2] = "Bathinda";
        cities[3] = "Faridkot";
        cities[4] = "Fatehgarh Sahib";
        cities[5] = "Fazilka";
        cities[6] = "Ferozepur";
        cities[7] = "Gurdaspur";
        cities[8] = "Hoshiarpur";
        cities[9] = "Jalandhar";
        cities[10] = "Kapurthala";
        cities[11] = "Ludhiana";
        cities[12] = "Mansa";
        cities[13] = "Moga";
        cities[14] = "Muktsar";
        cities[15] = "Nawanshahr (Shahid Bhagat Singh Nagar)";
        cities[16] = "Pathankot";
        cities[17] = "Patiala";
        cities[18] = "Rupnagar";
        cities[19] = "Sahibzada Ajit Singh Nagar (Mohali)";
        cities[20] = "Sangrur";
        cities[21] = "Tarn Taran";
        
        for(int i = 0; i <= 21; i++) {
            if(cities[i].equals(city)){
                code = i;
            }
        }
        return code;
    }
    
    

    private int feerecord(int a, int b, int c) {
        
    int[][] fee_arr = new int[22][22];

fee_arr[0][0] = 0;
fee_arr[0][1] = 330;
fee_arr[0][2] = 344;
fee_arr[0][3] = 358;
fee_arr[0][4] = 372;
fee_arr[0][5] = 386;
fee_arr[0][6] = 400;
fee_arr[0][7] = 414;
fee_arr[0][8] = 428;
fee_arr[0][9] = 442;
fee_arr[0][10] = 456;
fee_arr[0][11] = 470;
fee_arr[0][12] = 484;
fee_arr[0][13] = 498;
fee_arr[0][14] = 512;
fee_arr[0][15] = 526;
fee_arr[0][16] = 540;
fee_arr[0][17] = 554;
fee_arr[0][18] = 568;
fee_arr[0][19] = 582;
fee_arr[0][20] = 596;
fee_arr[0][21] = 610;
fee_arr[1][0] = 316;
fee_arr[1][1] = 0;
fee_arr[1][2] = 344;
fee_arr[1][3] = 358;
fee_arr[1][4] = 372;
fee_arr[1][5] = 386;
fee_arr[1][6] = 400;
fee_arr[1][7] = 414;
fee_arr[1][8] = 428;
fee_arr[1][9] = 442;
fee_arr[1][10] = 456;
fee_arr[1][11] = 470;
fee_arr[1][12] = 484;
fee_arr[1][13] = 498;
fee_arr[1][14] = 512;
fee_arr[1][15] = 526;
fee_arr[1][16] = 540;
fee_arr[1][17] = 554;
fee_arr[1][18] = 568;
fee_arr[1][19] = 582;
fee_arr[1][20] = 596;
fee_arr[1][21] = 610;
fee_arr[2][0] = 316;
fee_arr[2][1] = 330;
fee_arr[2][2] = 0;
fee_arr[2][3] = 358;
fee_arr[2][4] = 372;
fee_arr[2][5] = 386;
fee_arr[2][6] = 400;
fee_arr[2][7] = 414;
fee_arr[2][8] = 428;
fee_arr[2][9] = 442;
fee_arr[2][10] = 456;
fee_arr[2][11] = 470;
fee_arr[2][12] = 484;
fee_arr[2][13] = 498;
fee_arr[2][14] = 512;
fee_arr[2][15] = 526;
fee_arr[2][16] = 540;
fee_arr[2][17] = 554;
fee_arr[2][18] = 568;
fee_arr[2][19] = 582;
fee_arr[2][20] = 596;
fee_arr[2][21] = 610;
fee_arr[3][0] = 316;
fee_arr[3][1] = 330;
fee_arr[3][2] = 344;
fee_arr[3][3] = 0;
fee_arr[3][4] = 372;
fee_arr[3][5] = 386;
fee_arr[3][6] = 400;
fee_arr[3][7] = 414;
fee_arr[3][8] = 428;
fee_arr[3][9] = 442;
fee_arr[3][10] = 456;
fee_arr[3][11] = 470;
fee_arr[3][12] = 484;
fee_arr[3][13] = 498;
fee_arr[3][14] = 512;
fee_arr[3][15] = 526;
fee_arr[3][16] = 540;
fee_arr[3][17] = 554;
fee_arr[3][18] = 568;
fee_arr[3][19] = 582;
fee_arr[3][20] = 596;
fee_arr[3][21] = 610;
fee_arr[4][0] = 316;
fee_arr[4][1] = 330;
fee_arr[4][2] = 344;
fee_arr[4][3] = 358;
fee_arr[4][4] = 0;
fee_arr[4][5] = 386;
fee_arr[4][6] = 400;
fee_arr[4][7] = 414;
fee_arr[4][8] = 428;
fee_arr[4][9] = 442;
fee_arr[4][10] = 456;
fee_arr[4][11] = 470;
fee_arr[4][12] = 484;
fee_arr[4][13] = 498;
fee_arr[4][14] = 512;
fee_arr[4][15] = 526;
fee_arr[4][16] = 540;
fee_arr[4][17] = 554;
fee_arr[4][18] = 568;
fee_arr[4][19] = 582;
fee_arr[4][20] = 596;
fee_arr[4][21] = 610;
fee_arr[5][0] = 316;
fee_arr[5][1] = 330;
fee_arr[5][2] = 344;
fee_arr[5][3] = 358;
fee_arr[5][4] = 372;
fee_arr[5][5] = 0;
fee_arr[5][6] = 400;
fee_arr[5][7] = 414;
fee_arr[5][8] = 428;
fee_arr[5][9] = 442;
fee_arr[5][10] = 456;
fee_arr[5][11] = 470;
fee_arr[5][12] = 484;
fee_arr[5][13] = 498;
fee_arr[5][14] = 512;
fee_arr[5][15] = 526;
fee_arr[5][16] = 540;
fee_arr[5][17] = 554;
fee_arr[5][18] = 568;
fee_arr[5][19] = 582;
fee_arr[5][20] = 596;
fee_arr[5][21] = 610;
fee_arr[6][0] = 316;
fee_arr[6][1] = 330;
fee_arr[6][2] = 344;
fee_arr[6][3] = 358;
fee_arr[6][4] = 372;
fee_arr[6][5] = 386;
fee_arr[6][6] = 0;
fee_arr[6][7] = 414;
fee_arr[6][8] = 428;
fee_arr[6][9] = 442;
fee_arr[6][10] = 456;
fee_arr[6][11] = 470;
fee_arr[6][12] = 484;
fee_arr[6][13] = 498;
fee_arr[6][14] = 512;
fee_arr[6][15] = 526;
fee_arr[6][16] = 540;
fee_arr[6][17] = 554;
fee_arr[6][18] = 568;
fee_arr[6][19] = 582;
fee_arr[6][20] = 596;
fee_arr[6][21] = 610;
fee_arr[7][0] = 316;
fee_arr[7][1] = 330;
fee_arr[7][2] = 344;
fee_arr[7][3] = 358;
fee_arr[7][4] = 372;
fee_arr[7][5] = 386;
fee_arr[7][6] = 400;
fee_arr[7][7] = 0;
fee_arr[7][8] = 428;
fee_arr[7][9] = 442;
fee_arr[7][10] = 456;
fee_arr[7][11] = 470;
fee_arr[7][12] = 484;
fee_arr[7][13] = 498;
fee_arr[7][14] = 512;
fee_arr[7][15] = 526;
fee_arr[7][16] = 540;
fee_arr[7][17] = 554;
fee_arr[7][18] = 568;
fee_arr[7][19] = 582;
fee_arr[7][20] = 596;
fee_arr[7][21] = 610;
fee_arr[8][0] = 316;
fee_arr[8][1] = 330;
fee_arr[8][2] = 344;
fee_arr[8][3] = 358;
fee_arr[8][4] = 372;
fee_arr[8][5] = 386;
fee_arr[8][6] = 400;
fee_arr[8][7] = 414;
fee_arr[8][8] = 0;
fee_arr[8][9] = 442;
fee_arr[8][10] = 456;
fee_arr[8][11] = 470;
fee_arr[8][12] = 484;
fee_arr[8][13] = 498;
fee_arr[8][14] = 512;
fee_arr[8][15] = 526;
fee_arr[8][16] = 540;
fee_arr[8][17] = 554;
fee_arr[8][18] = 568;
fee_arr[8][19] = 582;
fee_arr[8][20] = 596;
fee_arr[8][21] = 610;
fee_arr[9][0] = 316;
fee_arr[9][1] = 330;
fee_arr[9][2] = 344;
fee_arr[9][3] = 358;
fee_arr[9][4] = 372;
fee_arr[9][5] = 386;
fee_arr[9][6] = 400;
fee_arr[9][7] = 414;
fee_arr[9][8] = 428;
fee_arr[9][9] = 0;
fee_arr[9][10] = 456;
fee_arr[9][11] = 470;
fee_arr[9][12] = 484;
fee_arr[9][13] = 498;
fee_arr[9][14] = 512;
fee_arr[9][15] = 526;
fee_arr[9][16] = 540;
fee_arr[9][17] = 554;
fee_arr[9][18] = 568;
fee_arr[9][19] = 582;
fee_arr[9][20] = 596;
fee_arr[9][21] = 610;
fee_arr[10][0] = 316;
fee_arr[10][1] = 330;
fee_arr[10][2] = 344;
fee_arr[10][3] = 358;
fee_arr[10][4] = 372;
fee_arr[10][5] = 386;
fee_arr[10][6] = 400;
fee_arr[10][7] = 414;
fee_arr[10][8] = 428;
fee_arr[10][9] = 442;
fee_arr[10][10] = 0;
fee_arr[10][11] = 470;
fee_arr[10][12] = 484;
fee_arr[10][13] = 498;
fee_arr[10][14] = 512;
fee_arr[10][15] = 526;
fee_arr[10][16] = 540;
fee_arr[10][17] = 554;
fee_arr[10][18] = 568;
fee_arr[10][19] = 582;
fee_arr[10][20] = 596;
fee_arr[10][21] = 610;
fee_arr[11][0] = 316;
fee_arr[11][1] = 330;
fee_arr[11][2] = 344;
fee_arr[11][3] = 358;
fee_arr[11][4] = 372;
fee_arr[11][5] = 386;
fee_arr[11][6] = 400;
fee_arr[11][7] = 414;
fee_arr[11][8] = 428;
fee_arr[11][9] = 442;
fee_arr[11][10] = 456;
fee_arr[11][11] = 0;
fee_arr[11][12] = 484;
fee_arr[11][13] = 498;
fee_arr[11][14] = 512;
fee_arr[11][15] = 526;
fee_arr[11][16] = 540;
fee_arr[11][17] = 554;
fee_arr[11][18] = 568;
fee_arr[11][19] = 582;
fee_arr[11][20] = 596;
fee_arr[11][21] = 610;
fee_arr[12][0] = 316;
fee_arr[12][1] = 330;
fee_arr[12][2] = 344;
fee_arr[12][3] = 358;
fee_arr[12][4] = 372;
fee_arr[12][5] = 386;
fee_arr[12][6] = 400;
fee_arr[12][7] = 414;
fee_arr[12][8] = 428;
fee_arr[12][9] = 442;
fee_arr[12][10] = 456;
fee_arr[12][11] = 470;
fee_arr[12][12] = 0;
fee_arr[12][13] = 498;
fee_arr[12][14] = 512;
fee_arr[12][15] = 526;
fee_arr[12][16] = 540;
fee_arr[12][17] = 554;
fee_arr[12][18] = 568;
fee_arr[12][19] = 582;
fee_arr[12][20] = 596;
fee_arr[12][21] = 610;
fee_arr[13][0] = 316;
fee_arr[13][1] = 330;
fee_arr[13][2] = 344;
fee_arr[13][3] = 358;
fee_arr[13][4] = 372;
fee_arr[13][5] = 386;
fee_arr[13][6] = 400;
fee_arr[13][7] = 414;
fee_arr[13][8] = 428;
fee_arr[13][9] = 442;
fee_arr[13][10] = 456;
fee_arr[13][11] = 470;
fee_arr[13][12] = 484;
fee_arr[13][13] = 0;
fee_arr[13][14] = 512;
fee_arr[13][15] = 526;
fee_arr[13][16] = 540;
fee_arr[13][17] = 554;
fee_arr[13][18] = 568;
fee_arr[13][19] = 582;
fee_arr[13][20] = 596;
fee_arr[13][21] = 610;
fee_arr[14][0] = 316;
fee_arr[14][1] = 330;
fee_arr[14][2] = 344;
fee_arr[14][3] = 358;
fee_arr[14][4] = 372;
fee_arr[14][5] = 386;
fee_arr[14][6] = 400;
fee_arr[14][7] = 414;
fee_arr[14][8] = 428;
fee_arr[14][9] = 442;
fee_arr[14][10] = 456;
fee_arr[14][11] = 470;
fee_arr[14][12] = 484;
fee_arr[14][13] = 498;
fee_arr[14][14] = 0;
fee_arr[14][15] = 526;
fee_arr[14][16] = 540;
fee_arr[14][17] = 554;
fee_arr[14][18] = 568;
fee_arr[14][19] = 582;
fee_arr[14][20] = 596;
fee_arr[14][21] = 610;
fee_arr[15][0] = 316;
fee_arr[15][1] = 330;
fee_arr[15][2] = 344;
fee_arr[15][3] = 358;
fee_arr[15][4] = 372;
fee_arr[15][5] = 386;
fee_arr[15][6] = 400;
fee_arr[15][7] = 414;
fee_arr[15][8] = 428;
fee_arr[15][9] = 442;
fee_arr[15][10] = 456;
fee_arr[15][11] = 470;
fee_arr[15][12] = 484;
fee_arr[15][13] = 498;
fee_arr[15][14] = 512;
fee_arr[15][15] = 0;
fee_arr[15][16] = 540;
fee_arr[15][17] = 554;
fee_arr[15][18] = 568;
fee_arr[15][19] = 582;
fee_arr[15][20] = 596;
fee_arr[15][21] = 610;
fee_arr[16][0] = 316;
fee_arr[16][1] = 330;
fee_arr[16][2] = 344;
fee_arr[16][3] = 358;
fee_arr[16][4] = 372;
fee_arr[16][5] = 386;
fee_arr[16][6] = 400;
fee_arr[16][7] = 414;
fee_arr[16][8] = 428;
fee_arr[16][9] = 442;
fee_arr[16][10] = 456;
fee_arr[16][11] = 470;
fee_arr[16][12] = 484;
fee_arr[16][13] = 498;
fee_arr[16][14] = 512;
fee_arr[16][15] = 526;
fee_arr[16][16] = 0;
fee_arr[16][17] = 554;
fee_arr[16][18] = 568;
fee_arr[16][19] = 582;
fee_arr[16][20] = 596;
fee_arr[16][21] = 610;
fee_arr[17][0] = 316;
fee_arr[17][1] = 330;
fee_arr[17][2] = 344;
fee_arr[17][3] = 358;
fee_arr[17][4] = 372;
fee_arr[17][5] = 386;
fee_arr[17][6] = 400;
fee_arr[17][7] = 414;
fee_arr[17][8] = 428;
fee_arr[17][9] = 442;
fee_arr[17][10] = 456;
fee_arr[17][11] = 470;
fee_arr[17][12] = 484;
fee_arr[17][13] = 498;
fee_arr[17][14] = 512;
fee_arr[17][15] = 526;
fee_arr[17][16] = 540;
fee_arr[17][17] = 0;
fee_arr[17][18] = 568;
fee_arr[17][19] = 582;
fee_arr[17][20] = 596;
fee_arr[17][21] = 610;
fee_arr[18][0] = 316;
fee_arr[18][1] = 330;
fee_arr[18][2] = 344;
fee_arr[18][3] = 358;
fee_arr[18][4] = 372;
fee_arr[18][5] = 386;
fee_arr[18][6] = 400;
fee_arr[18][7] = 414;
fee_arr[18][8] = 428;
fee_arr[18][9] = 442;
fee_arr[18][10] = 456;
fee_arr[18][11] = 470;
fee_arr[18][12] = 484;
fee_arr[18][13] = 498;
fee_arr[18][14] = 512;
fee_arr[18][15] = 526;
fee_arr[18][16] = 540;
fee_arr[18][17] = 554;
fee_arr[18][18] = 0;
fee_arr[18][19] = 582;
fee_arr[18][20] = 596;
fee_arr[18][21] = 610;
fee_arr[19][0] = 316;
fee_arr[19][1] = 330;
fee_arr[19][2] = 344;
fee_arr[19][3] = 358;
fee_arr[19][4] = 372;
fee_arr[19][5] = 386;
fee_arr[19][6] = 400;
fee_arr[19][7] = 414;
fee_arr[19][8] = 428;
fee_arr[19][9] = 442;
fee_arr[19][10] = 456;
fee_arr[19][11] = 470;
fee_arr[19][12] = 484;
fee_arr[19][13] = 498;
fee_arr[19][14] = 512;
fee_arr[19][15] = 526;
fee_arr[19][16] = 540;
fee_arr[19][17] = 554;
fee_arr[19][18] = 568;
fee_arr[19][19] = 0;
fee_arr[19][20] = 596;
fee_arr[19][21] = 610;
fee_arr[20][0] = 316;
fee_arr[20][1] = 330;
fee_arr[20][2] = 344;
fee_arr[20][3] = 358;
fee_arr[20][4] = 372;
fee_arr[20][5] = 386;
fee_arr[20][6] = 400;
fee_arr[20][7] = 414;
fee_arr[20][8] = 428;
fee_arr[20][9] = 442;
fee_arr[20][10] = 456;
fee_arr[20][11] = 470;
fee_arr[20][12] = 484;
fee_arr[20][13] = 498;
fee_arr[20][14] = 512;
fee_arr[20][15] = 526;
fee_arr[20][16] = 540;
fee_arr[20][17] = 554;
fee_arr[20][18] = 568;
fee_arr[20][19] = 582;
fee_arr[20][20] = 0;
fee_arr[20][21] = 610;
fee_arr[21][0] = 316;
fee_arr[21][1] = 330;
fee_arr[21][2] = 344;
fee_arr[21][3] = 358;
fee_arr[21][4] = 372;
fee_arr[21][5] = 386;
fee_arr[21][6] = 400;
fee_arr[21][7] = 414;
fee_arr[21][8] = 428;
fee_arr[21][9] = 442;
fee_arr[21][10] = 456;
fee_arr[21][11] = 470;
fee_arr[21][12] = 484;
fee_arr[21][13] = 498;
fee_arr[21][14] = 512;
fee_arr[21][15] = 526;
fee_arr[21][16] = 540;
fee_arr[21][17] = 554;
fee_arr[21][18] = 568;
fee_arr[21][19] = 582;
fee_arr[21][20] = 596;
fee_arr[21][21] = 0;
    
    if(c < 0)
        return fee_arr[a][b];
    else {
        fee_arr[a][b] = c;
        return 0;
    }
}
        
        
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Top_Panel1 = new javax.swing.JPanel();
        Registration_Form1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Change Fare");
        setAlwaysOnTop(true);
        setBounds(new java.awt.Rectangle(250, 200, 900, 450));
        setResizable(false);
        getContentPane().setLayout(null);

        Top_Panel1.setBackground(new java.awt.Color(153, 153, 153));

        Registration_Form1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        Registration_Form1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Registration_Form1.setText("Change Fare");

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/backButton.png"))); // NOI18N
        jButton2.setBorder(null);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Top_Panel1Layout = new javax.swing.GroupLayout(Top_Panel1);
        Top_Panel1.setLayout(Top_Panel1Layout);
        Top_Panel1Layout.setHorizontalGroup(
            Top_Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Top_Panel1Layout.createSequentialGroup()
                .addComponent(jButton2)
                .addGap(202, 202, 202)
                .addComponent(Registration_Form1)
                .addContainerGap(234, Short.MAX_VALUE))
        );
        Top_Panel1Layout.setVerticalGroup(
            Top_Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Registration_Form1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(Top_Panel1Layout.createSequentialGroup()
                .addComponent(jButton2)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(Top_Panel1);
        Top_Panel1.setBounds(0, 0, 710, 44);

        jComboBox2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Amritsar", "Barnala", "Bathinda", "Faridkot", "Fatehgarh Sahib", "Fazilka", "Ferozepur", "Gurdaspur", "Hoshiarpur", "Jalandhar", "Kapurthala", "Ludhiana", "Mansa", "Moga", "Muktsar", "Nawanshahr (Shahid Bhagat Singh Nagar)", "Pathankot", "Patiala", "Rupnagar", "Sahibzada Ajit Singh Nagar (Mohali)", "Sangrur", "Tarn Taran" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox2);
        jComboBox2.setBounds(420, 220, 230, 40);

        jComboBox3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Amritsar", "Barnala", "Bathinda", "Faridkot", "Fatehgarh Sahib", "Fazilka", "Ferozepur", "Gurdaspur", "Hoshiarpur", "Jalandhar", "Kapurthala", "Ludhiana", "Mansa", "Moga", "Muktsar", "Nawanshahr (Shahid Bhagat Singh Nagar)", "Pathankot", "Patiala", "Rupnagar", "Sahibzada Ajit Singh Nagar (Mohali)", "Sangrur", "Tarn Taran" }));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox3);
        jComboBox3.setBounds(60, 220, 230, 40);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setText("To");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(340, 220, 40, 50);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setText("Initial Fare : ");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(172, 270, 170, 30);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setText("New Fare : ");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(190, 310, 140, 30);

        jTextField2.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jTextField2.setText("0");
        getContentPane().add(jTextField2);
        jTextField2.setBounds(380, 305, 180, 40);

        jButton1.setBackground(new java.awt.Color(51, 51, 51));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton1.setText("Refresh");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(90, 360, 180, 50);

        jButton3.setBackground(new java.awt.Color(51, 51, 51));
        jButton3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton3.setText("Change");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(440, 360, 180, 50);

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel1.setText("Rs. ");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(340, 270, 44, 30);

        jLabel6.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel6.setText("Rs. ");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(340, 310, 44, 30);

        jLabel5.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel5.setText("699");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(380, 269, 180, 30);

        jLabel7.setBackground(new java.awt.Color(153, 153, 153));
        jLabel7.setOpaque(true);
        getContentPane().add(jLabel7);
        jLabel7.setBounds(-20, 130, 740, 290);

        setSize(new java.awt.Dimension(716, 539));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed

    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Settings m = new Settings();
        m.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String froms = jComboBox3.getSelectedItem().toString();
        String tos = jComboBox2.getSelectedItem().toString();
        to_find = "fee_arr[" + citytoint(froms) + "][" + citytoint(tos) + "] = ";
        String dbrecord = "";
                
        try {  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            //Executing statement1
            try (Connection con = DriverManager.getConnection(Database_Properties.getUrl(), Database_Properties.getUsername(), Database_Properties.getPassword())) {
                try ( //Executing statement1
                    PreparedStatement stmt1 = con.prepareStatement("SELECT Fare_Record.Fare FROM Fare_Record")) {
                    ResultSet rs1 = stmt1.executeQuery();
                    
                    rs1.next();
                    dbrecord = rs1.getString("Fare");
                }
                con.close();
            }
        }
        catch(ClassNotFoundException | SQLException e){System.out.println(e);} 
        
        int faredigitsplace = dbrecord.indexOf(to_find) + to_find.length() - 1;
        String buff = "";
        
        while(dbrecord.charAt(faredigitsplace) != ';') {
            buff = buff + dbrecord.charAt(faredigitsplace);
            faredigitsplace++;
        }
        
        jLabel5.setText(String.valueOf(buff));
        
        
        
        
      
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if(jTextField2.getText().matches("[0-9]+")) {
            chagefare();
        }
        else
            JOptionPane.showMessageDialog(this, "Please enter a valid input!");
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Change_Fare.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        
  
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Change_Fare().setVisible(true);
        });
    }
    
    public void chagefare() {
        String textfield = jTextField2.getText();
        try {  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            //Executing statement1
            try (Connection con = DriverManager.getConnection(Database_Properties.getUrl(), Database_Properties.getUsername(), Database_Properties.getPassword())) {
                PreparedStatement stmt2;
                try ( //Executing statement1
                    PreparedStatement stmt1 = con.prepareStatement("SELECT Fare_Record.Fare FROM Fare_Record")) {
                    ResultSet rs1 = stmt1.executeQuery();
                    rs1.next();
                    String dbrecord = rs1.getString("Fare");
                    int faredigitsplace = dbrecord.indexOf(to_find) + to_find.length();
                    StringBuilder newdbrecord = new StringBuilder(dbrecord);
                    newdbrecord.replace(faredigitsplace, (faredigitsplace + textfield.length()+1), textfield.concat(";"));
                    stmt2 = con.prepareStatement("UPDATE Fare_Record SET Fare = ?");
                    stmt2.setString(1, newdbrecord.toString());
                    stmt2.executeUpdate();
                }
                stmt2.close();
                con.close();
                JOptionPane.showMessageDialog(this, "Successfull");
            }
        }
        catch(ClassNotFoundException | SQLException e){System.out.println(e);}
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Registration_Form1;
    private javax.swing.JPanel Top_Panel1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
