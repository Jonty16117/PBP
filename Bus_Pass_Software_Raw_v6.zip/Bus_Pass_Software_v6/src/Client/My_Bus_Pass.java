/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import Common.Database_Properties;
import java.sql.*;
import java.io.*; 
import java.nio.file.FileSystems;
import java.nio.file.Path;
//import javax.swing.JOptionPane;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import org.apache.commons.codec.binary.Base64;



/**
 *
 * @author Jonty
 */
public class My_Bus_Pass extends javax.swing.JFrame {
    
    public String record_arr[] = new String[21];
    public String pass_id = "";
    public String QR_CODE_IMAGE_PATH = "MyQRCode.png";
    
    /**
     *
     * @param fileName
     * @return
     * @throws IOException
     */
    public static String readFile(String fileName) throws IOException {
            try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append("\n");
                line = br.readLine();
            }
            return sb.toString();
            }
    }
    
    public void writeImage(String des, String encodedImage) throws IOException {
        byte[] imageByteArray = Base64.decodeBase64(encodedImage);
        try (ByteArrayInputStream inputStream = new ByteArrayInputStream(imageByteArray)) {
            BufferedImage bi = ImageIO.read(inputStream);
            File f = new File(des);
            ImageIO.write(bi, "png", f);
            inputStream.close();
        }
    }
    
    private static void generateQRCodeImage(String text, int width, int height, String filePath) throws WriterException, IOException {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        BitMatrix bitMatrix = qrCodeWriter.encode(text, BarcodeFormat.QR_CODE, width, height);

        Path path = FileSystems.getDefault().getPath(filePath);
        MatrixToImageWriter.writeToPath(bitMatrix, "PNG", path);
    }
    
    /**
     * Creates new form Main_Frame
     */
    public My_Bus_Pass() {

        try {
            String client_id = readFile("client_id.bin");
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(Database_Properties.getUrl(), Database_Properties.getUsername(), Database_Properties.getPassword())) {
                PreparedStatement stmt1 = con.prepareStatement("SELECT Clients_Info.Record_File FROM Clients_Info WHERE Client_Id = ?");
                stmt1.setString(1, client_id);
                ResultSet rs1 = stmt1.executeQuery();

                //md5 of remote database file
                rs1.next();
                String remotemd5 = rs1.getString("Record_File");
                System.out.println(remotemd5);
                
                //md5 of local database file
                String localmd5 = readFile("localmd5.bin");

                //comparing both md5
                boolean chk = true;

                if ((localmd5.length() < 32)) {
                    chk = false;
                } else {
                    for (int i = 0; i < 32; i++) {
                        if (!(remotemd5.charAt(i) == localmd5.charAt(i))) {
                            chk = false;
                        }
                    }
                }

                if (!chk) {
                    try (FileWriter os = new FileWriter("localmd5.bin")) {
                        os.write(remotemd5);
                        os.close();
                        //this.setVisible(false);
                        //JOptionPane.showMessageDialog(this, "Files updated, please restart!!");
                        System.out.println("Files Updated!");
                        System.exit(0);

                    }
                } else {
                    localmd5 = readFile("localmd5.bin");//get the final string of record file
                }

                //System.out.println(localmd5);
                //Getting record_file data
                Character buff1 = '!';
                String buff2 = "";
                int j = 0;
                for (int i = 32; i < localmd5.length(); i++) { //33 = 32bit of md5 checksumm + 1th position is where the data starts
                    if (localmd5.charAt(i) == '^' || localmd5.charAt(i) == '&') {
                        if (localmd5.charAt(i + 1) == '&') {
                            if (localmd5.charAt(i + 2) == '^' && (j < record_arr.length)) {
                                record_arr[j] = buff2;
                                buff2 = "";
                                j++;
                            }
                        }
                    } else {
                        buff1 = localmd5.charAt(i);
                        buff2 = buff2 + buff1.toString();
                    }
                }
            }
        } catch (IOException | ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }

        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Top_Panel1 = new javax.swing.JPanel();
        Registration_Form1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        try {
            String client_id = readFile("client_id.bin");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(Database_Properties.getUrl(), Database_Properties.getUsername(), Database_Properties.getPassword());
            PreparedStatement stmt1 = con.prepareStatement("SELECT Pass_Info.Pass_Id FROM Pass_Info WHERE Client_Id = ?");
            stmt1.setString(1, client_id);
            ResultSet rs1 = stmt1.executeQuery();
            rs1.next();
            pass_id = rs1.getString("Pass_Id");
            con.close();
        }
        catch(IOException | ClassNotFoundException | SQLException e){System.out.println(e);}

        try {
            System.out.println(pass_id);
            generateQRCodeImage(pass_id, 100, 100, QR_CODE_IMAGE_PATH);
        }
        catch (WriterException e) {System.out.println("Could not generate QR Code, WriterException :: " + e.getMessage());}
        catch (IOException e) {System.out.println("Could not generate QR Code, IOException :: " + e.getMessage());}
        jLabel1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Pass");
        setAlwaysOnTop(true);
        setBounds(new java.awt.Rectangle(250, 200, 900, 450));
        setResizable(false);
        getContentPane().setLayout(null);

        Top_Panel1.setBackground(new java.awt.Color(153, 153, 153));

        Registration_Form1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        Registration_Form1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Registration_Form1.setText("My Pass");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Back_Button.png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Top_Panel1Layout = new javax.swing.GroupLayout(Top_Panel1);
        Top_Panel1.setLayout(Top_Panel1Layout);
        Top_Panel1Layout.setHorizontalGroup(
            Top_Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Top_Panel1Layout.createSequentialGroup()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(251, 251, 251)
                .addComponent(Registration_Form1)
                .addContainerGap(261, Short.MAX_VALUE))
        );
        Top_Panel1Layout.setVerticalGroup(
            Top_Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Top_Panel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(Registration_Form1))
        );

        getContentPane().add(Top_Panel1);
        Top_Panel1.setBounds(0, 0, 710, 44);

        jLabel2.setFont(new java.awt.Font("DejaVu Sans Mono", 1, 24)); // NOI18N
        jLabel2.setText(record_arr[0]);
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 230, 420, 40);

        jLabel3.setFont(new java.awt.Font("DejaVu Sans Mono", 1, 48)); // NOI18N
        jLabel3.setText(record_arr[18]);
        getContentPane().add(jLabel3);
        jLabel3.setBounds(20, 170, 310, 50);

        jLabel4.setFont(new java.awt.Font("DejaVu Sans Mono", 0, 24)); // NOI18N
        jLabel4.setText(record_arr[6]);
        getContentPane().add(jLabel4);
        jLabel4.setBounds(100, 310, 420, 30);

        jLabel5.setFont(new java.awt.Font("DejaVu Sans Mono", 1, 24)); // NOI18N
        jLabel5.setText(record_arr[15]);
        getContentPane().add(jLabel5);
        jLabel5.setBounds(20, 266, 420, 40);

        jLabel6.setFont(new java.awt.Font("DejaVu Sans Mono", 0, 14)); // NOI18N
        jLabel6.setText("Terms and Conditions Apply\n\n");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(240, 480, 220, 20);

        jLabel8.setFont(new java.awt.Font("DejaVu Sans Mono", 0, 18)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText(record_arr[8]);
        getContentPane().add(jLabel8);
        jLabel8.setBounds(40, 410, 630, 60);

        jLabel9.setFont(new java.awt.Font("DejaVu Sans Mono", 0, 24)); // NOI18N
        jLabel9.setText(record_arr[7]);
        getContentPane().add(jLabel9);
        jLabel9.setBounds(100, 360, 420, 30);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new ImageIcon("./MyQRCode.png"));
        getContentPane().add(jLabel1);
        jLabel1.setBounds(406, 176, 70, 70);

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        try {
            String client_id = readFile("client_id.bin");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(Database_Properties.getUrl(), Database_Properties.getUsername(), Database_Properties.getPassword());

            PreparedStatement stmt2 = con.prepareStatement("SELECT Clients_Info.Client_Photo FROM Clients_Info WHERE Client_Id = ?");
            stmt2.setString(1, client_id);
            ResultSet rs2 = stmt2.executeQuery();
            rs2.next();
            String client_image = rs2.getString("Client_Photo");
            writeImage("client_image.jpg", client_image);

            con.close();
        }
        catch(IOException | ClassNotFoundException | SQLException e){System.out.println(e);}
        jLabel10.setIcon(new javax.swing.ImageIcon("client_image.jpg"));
        getContentPane().add(jLabel10);
        jLabel10.setBounds(530, 134, 160, 200);

        jLabel7.setBackground(new java.awt.Color(153, 153, 153));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Bus_Pass_Template.png"))); // NOI18N
        jLabel7.setOpaque(true);
        getContentPane().add(jLabel7);
        jLabel7.setBounds(-10, 45, 730, 480);
        jLabel3.setText(record_arr[18]);
        jLabel2.setText(record_arr[0]);
        jLabel5.setText(record_arr[16]);
        jLabel4.setText(record_arr[6]);
        jLabel9.setText(record_arr[7]);
        jLabel8.setText(record_arr[8]);

        setSize(new java.awt.Dimension(716, 539));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Client_Main_Page c = new Client_Main_Page();
        c.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {        
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(My_Bus_Pass.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new My_Bus_Pass().setVisible(true);
            }
        });
        

        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Registration_Form1;
    private javax.swing.JPanel Top_Panel1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables
}
