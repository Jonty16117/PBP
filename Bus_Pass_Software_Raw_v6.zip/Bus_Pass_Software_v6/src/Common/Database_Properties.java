/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Common;

/**
 *
 * @author Jonty
 */
public class Database_Properties {
    public static String getUrl() {
        return "jdbc:mysql://db4free.net:3306/bus_pass_db";
    }
    
    public static String getUsername() {
        return "manager_buss_pas";
    }
    
    public static String getPassword() {
        return "administrator";
    }
}
